#include "string_hash.hpp"

unsigned char string_hash(std::string s) {
	
	// für das Hashing werden verschiedene Berechnungen auf dem String s durchgeführt
	// das Ergebnis soll in einem int zwischengespeichert werden
	int ret = 0;
   
	// führen Sie hier die auf dem Blatt angegebenen Berechnungen durchgeführt...
	
	// weil später ein char als key verwendet wird, muss hier noch ein cast durchgeführt werden
	return (unsigned char)ret;
}