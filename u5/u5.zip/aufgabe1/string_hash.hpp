#ifndef __STRING_HASH_HPP__
#define __STRING_HASH_HPP__

#include <string>

unsigned char string_hash(std::string);

#endif

