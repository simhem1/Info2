#ifndef __SPACESHIP_HPP__
#define __SPACESHIP_HPP__

#include <string>

class Spaceship {
 public:
  
	 // Eigenschaften der Raumschiffe
	 
	 // Konstruktor
	 
	 // Hier wird der Operator überladen, diesen Teil geben wir noch vor, die Implementierung
	 // muss aber selbstständig gelöst werden!
	 bool operator==(Spaceship);
};

#endif

