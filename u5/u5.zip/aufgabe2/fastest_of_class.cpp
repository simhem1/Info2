#include "fastest_of_class.hpp"
